Contains implementation of BitNodes and BitNode-specific mechanics

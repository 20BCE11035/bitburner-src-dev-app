Implementation of Company and Job related mechanics

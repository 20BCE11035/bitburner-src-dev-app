export const StanekConstants = {
  RAMBonus: 0.1,
  BaseSize: 9,
  MaxSize: 25,
};

# Grafting

Grafting is an experimental process through which you can obtain the benefits of [Augmentations](../basic/augmentations.md), without needing to reboot your body.

Grafting can be done at VitaLife in New Tokyo, where you'll find a shady researcher with questionable connections.
From there, you can spend a sum of money to begin grafting [Augmentations](../basic/augmentations.md).
This will take some time.
When done, the [Augmentation](../basic/augmentations.md) will be applied to your character without needing to install.

Be warned, some who have tested grafting have reported an unidentified malware.
Dubbed `Entropy`, this virus seems to grow in potency as more [Augmentations](../basic/augmentations.md) are grafted, causing unpredictable affects to the victim.

Note that when grafting an [Augmentation](../basic/augmentations.md), cancelling will **not** save your progress, and the money spent will **not** be returned.

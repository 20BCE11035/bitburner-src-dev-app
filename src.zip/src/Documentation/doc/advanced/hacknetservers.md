# Hacknet Servers

These are a very powerful upgrade to [Hacknet Nodes](../basic/hacknet_nodes.md).
Instead of producing money, the Hacknet Servers produce `hashes`.
This currency can be exchanged for a variety of upgrades that boost most other mechanics of the game.

They can also be used to run scripts on.
However, this reduces the amount of `hash` produced.

# Hacknet nodes

This distributed network of computers allows you to gain passive income.
By upgrading a node's level, RAM, and CPU cores you can increase the amount of money it earns.
You can also purchase new nodes to expand your Hacknet - The cost for each node increases as your network grows.

**Hacknet nodes won't make as much money as basic hacking scripts, and they are not enough to progress alone.**

Later in the game, there is a powerful change to the Hacknet system called [Hacknet Servers](../advanced/hacknetservers.md).

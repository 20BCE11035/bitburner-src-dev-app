# World

In Bitburner, the world consists of six different cities:

- Sector-12 (this is where you start out)
- Aevum
- Ishima
- New Tokyo
- Chongqing
- Volhaven

Each city has its own map and [Factions](factions.md).
Each city also offers different services such as gyms, universities, hardware stores, and places of work.

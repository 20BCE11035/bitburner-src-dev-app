Implementation of Faction-related mechanics

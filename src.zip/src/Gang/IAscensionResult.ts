export interface IAscensionResult {
  respect: number;
  hack: number;
  str: number;
  def: number;
  dex: number;
  agi: number;
  cha: number;
}

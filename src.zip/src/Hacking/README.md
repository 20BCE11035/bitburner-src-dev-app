Implementation of underlying Hacking mechanics

export interface Milestone {
  title: string;
  fulfilled: () => boolean;
}

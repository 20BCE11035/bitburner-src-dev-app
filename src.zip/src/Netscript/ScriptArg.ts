export type ScriptArg = string | number | boolean;

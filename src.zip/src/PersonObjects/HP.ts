export interface HP {
  current: number;
  max: number;
}

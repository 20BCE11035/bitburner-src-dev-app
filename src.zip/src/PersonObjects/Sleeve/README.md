Implements the "Duplicate Sleeves" feature, which allows the player to purchase
new duplicate sleeves. These are synthetic bodies that contain the player's
cloned consciousness. The player can use these sleeves to perform
different tasks synchronously.

This feature is introduced and unlocked in BitNode-10.

Note that while they are based on the same concept, this feature is different
than the "Re-sleeving" mechanic (which is referred to as "Resleeve" in the source code).
